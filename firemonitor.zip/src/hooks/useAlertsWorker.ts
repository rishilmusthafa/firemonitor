'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
// import { wrap } from 'comlink'; // Comlink import commented out
import { useVillas } from './useVillas';
import { useAlerts } from './useAlerts';
import { useUIStore } from '@/store/useUIStore';
import { filterLatestAlertsPerVilla } from '@/utils/dataUtils';
import type { NormalizedVilla } from '@/types/villas';
import type { Alert, ProcessedAlert } from '@/types/alerts';

interface ProcessTodayResult {
  openToday: number;
  totalToday: number;
  items: ProcessedAlert[];
}

interface AlertStats {
  totalAlerts: number;
  openAlerts: number;
  closedAlerts: number;
  overdueAlerts: number;
  countdownAlerts: number;
}

interface AlertsWorkerAPI {
  init: (params: { alerts: Alert[]; villas: NormalizedVilla[]; nowUtc: string }) => Promise<void>;
  processToday: (params: { nowUtc: string }) => Promise<ProcessTodayResult>;
  getAlertStats: () => Promise<AlertStats>;
  getAlertsByEmirate: (emirate: string) => Promise<Alert[]>;
}

// Simple synchronous implementation for testing (replaces worker)
class SimpleAlertsProcessor {
  private alerts: Alert[] = [];
  private villas: NormalizedVilla[] = [];
  private nowUtc: string = '';

  init({ alerts, villas, nowUtc }: { alerts: Alert[]; villas: NormalizedVilla[]; nowUtc: string }) {
    this.alerts = alerts;
    this.villas = villas;
    this.nowUtc = nowUtc;
  }

  processToday({ nowUtc }: { nowUtc: string }): Promise<ProcessTodayResult> {
    this.nowUtc = nowUtc;
    const now = new Date(nowUtc);
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);

    // TEMPORARY: Return all alerts instead of just today's for testing
    const todayAlerts = this.alerts; // Changed from filtering to all alerts

    // Process each alert
    const processedAlerts: ProcessedAlert[] = todayAlerts.map(alert => {
      const alertDate = new Date(alert.Alert_DateTime);
      const secondsSinceAlert = Math.floor((now.getTime() - alertDate.getTime()) / 1000);
      
      let status: 'closed' | 'countdown' | 'overdue';
      let secondsRemaining: number | undefined;

      if (alert.Status === 'Closed') {
        status = 'closed';
      } else {
        // Open alerts: check if within 2-minute window
        const twoMinutes = 2 * 60; // 2 minutes in seconds (120 seconds)
        
        // Only show countdown for recent alerts (within last 2 minutes)
        if (secondsSinceAlert >= 0 && secondsSinceAlert < twoMinutes) {
          status = 'countdown';
          secondsRemaining = twoMinutes - secondsSinceAlert;
        } else {
          status = 'overdue';
        }
      }

      return {
        id: alert.id,
        accountId: alert.Account_ID,
        title: alert.Title,
        titleAr: alert.Title_Ar,
        datetime: alert.Alert_DateTime,
        status,
        secondsRemaining,
        mobile: alert.Mobile,
        type: alert.Type,
      };
    });

    const openToday = processedAlerts.filter(alert => alert.status !== 'closed').length;
    const totalToday = processedAlerts.length;

    return Promise.resolve({
      openToday,
      totalToday,
      items: processedAlerts
    });
  }

  getAlertStats(): Promise<AlertStats> {
    const now = new Date(this.nowUtc);
    const twoMinutes = 2 * 60; // 2 minutes in seconds (120 seconds)

    let openAlerts = 0;
    let closedAlerts = 0;
    let overdueAlerts = 0;
    let countdownAlerts = 0;

    this.alerts.forEach(alert => {
      if (alert.Status === 'Closed') {
        closedAlerts++;
      } else {
        const alertDate = new Date(alert.Alert_DateTime);
        const secondsSinceAlert = Math.floor((now.getTime() - alertDate.getTime()) / 1000);
        
        // Only show countdown for recent alerts (within last 2 minutes)
        if (secondsSinceAlert >= 0 && secondsSinceAlert < twoMinutes) {
          countdownAlerts++;
        } else {
          overdueAlerts++;
        }
        openAlerts++;
      }
    });

    return Promise.resolve({
      totalAlerts: this.alerts.length,
      openAlerts,
      closedAlerts,
      overdueAlerts,
      countdownAlerts,
    });
  }

  getAlertsByEmirate(emirate: string): Promise<Alert[]> {
    if (emirate === 'All') {
      return Promise.resolve(this.alerts);
    }

    const emirateMapping: Record<string, string> = {
      'Dubai': 'Dubai',
      'Abu Dhabi': 'Abu Dhabi',
      'Sharjah': 'Sharjah',
      'Sharjah ': 'Sharjah', // Handle trailing space
      'Ajman': 'Ajman',
      'Umm Al Quwain': 'Umm Al Quwain',
      'Umm al Quwain': 'Umm Al Quwain', // Add lowercase 'al' variation
      'Ras Al Khaimah': 'Ras Al Khaimah',
      'Ras Al khaimah': 'Ras Al Khaimah', // Handle mixed case
      'Ras al-Khaimah': 'Ras Al Khaimah', // Handle hyphenated version
      'Fujairah': 'Fujairah',
      'Alain': 'Abu Dhabi', // Alain is part of Abu Dhabi
      'Tarif': 'Other', // Unknown location
    };

    // Get villa account numbers for the selected emirate
    const emirateVillaIds = new Set(
      this.villas
        .filter(villa => emirateMapping[villa.City] === emirate)
        .map(villa => villa.Account_Number)
    );

    // Filter alerts for villas in the selected emirate
    const filteredAlerts = this.alerts.filter(alert => emirateVillaIds.has(alert.Account_ID));
    

    
    return Promise.resolve(filteredAlerts);
  }
}

export function useAlertsWorker() {
  const processorRef = useRef<SimpleAlertsProcessor | null>(null); // Changed from workerRef
  // const workerApiRef = useRef<AlertsWorkerAPI | null>(null); // Commented out
  const [isWorkerReady, setIsWorkerReady] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [workerError, setWorkerError] = useState<string | null>(null);

  const { data: villasData } = useVillas();
  const { data: alertsData, isLoading: alertsLoading, error: alertsError } = useAlerts();
  const { emirate } = useUIStore();



  // Initialize processor
  useEffect(() => {
    try {
      if (!processorRef.current) {
        processorRef.current = new SimpleAlertsProcessor();
      }
    } catch (error) {
      console.error('Error creating SimpleAlertsProcessor:', error);
      setWorkerError('Failed to create SimpleAlertsProcessor');
    }

    return () => {
      if (processorRef.current) {
        processorRef.current = null;
        setIsWorkerReady(false);
        setWorkerError(null);
      }
    };
  }, []);

  // Initialize processor with data
  useEffect(() => {
    if (processorRef.current && villasData?.data && alertsData && !isWorkerReady) {
      const nowUtc = new Date().toISOString();
      
      try {
        // Ensure alertsData is an array
        const alertsArray = Array.isArray(alertsData) ? alertsData : [];
        
        // Apply filtering to remove duplicate alerts for the same villa
        const filteredAlerts = filterLatestAlertsPerVilla(alertsArray);
        
        processorRef.current.init({
          alerts: filteredAlerts,
          villas: villasData.data,
          nowUtc,
        });
        setIsWorkerReady(true);
        setWorkerError(null);
      } catch (error) {
        console.error('Failed to initialize SimpleAlertsProcessor:', error);
        setWorkerError('Failed to initialize SimpleAlertsProcessor with data');
      }
    }
  }, [villasData?.data, alertsData, isWorkerReady]);

  // Process today's alerts
  const processToday = useCallback(async () => {
    if (!processorRef.current || !isWorkerReady || isProcessing) {
      return { openToday: 0, totalToday: 0, items: [] };
    }

    setIsProcessing(true);
    try {
      const nowUtc = new Date().toISOString();
      const result = await processorRef.current.processToday({ nowUtc });
      return result;
    } catch (error) {
      console.error('Error processing today\'s alerts:', error);
      return { openToday: 0, totalToday: 0, items: [] };
    } finally {
      setIsProcessing(false);
    }
  }, [processorRef, isWorkerReady, isProcessing]);

  // Get alert statistics
  const getAlertStats = useCallback(async () => {
    if (!processorRef.current || !isWorkerReady) {
      return {
        totalAlerts: 0,
        openAlerts: 0,
        closedAlerts: 0,
        overdueAlerts: 0,
        countdownAlerts: 0,
      };
    }

    try {
      const result = await processorRef.current.getAlertStats();
      return result;
    } catch (error) {
      console.error('Error getting alert stats:', error);
      return {
        totalAlerts: 0,
        openAlerts: 0,
        closedAlerts: 0,
        overdueAlerts: 0,
        countdownAlerts: 0,
      };
    }
  }, [processorRef, isWorkerReady]);

  // Get alerts by emirate
  const getAlertsByEmirate = useCallback(async (emirateName: string) => {
    if (!processorRef.current || !isWorkerReady) {
      return [];
    }

    try {
      return await processorRef.current.getAlertsByEmirate(emirateName);
    } catch (error) {
      console.error('Error getting alerts by emirate:', error);
      return [];
    }
  }, [processorRef, isWorkerReady]);

  return {
    isWorkerReady,
    isProcessing,
    workerError,
    processToday,
    getAlertStats,
    getAlertsByEmirate,
  };
} 