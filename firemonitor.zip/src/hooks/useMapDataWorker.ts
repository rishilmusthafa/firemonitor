'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useVillas } from './useVillas';
import { useAlerts } from './useAlerts';
import { useUIStore } from '@/store/useUIStore';
import { useMapStore } from '@/store/useMapStore';
import type { NormalizedVilla } from '@/types/villas';
import type { Alert } from '@/types/alerts';

interface MapDataWorkerAPI {
  init: (params: { villas: NormalizedVilla[]; alerts: Alert[] }) => Promise<void>;
  filterAndCluster: (params: {
    viewportBounds: { west: number; east: number; south: number; north: number };
    cameraHeight: number;
    emirate: string;
    showNonAlertAboveZoom: boolean;
  }) => Promise<{
    clusters: Array<{ lon: number; lat: number; count: number }>;
    markers: Array<{
      id: string;
      lon: number;
      lat: number;
      isAlert: boolean;
      status?: 'open' | 'closed';
      accountNumber: string;
      customerName: string;
      alertData?: Alert;
    }>;
  }>;
  getEmirateBounds: (emirate: string) => Promise<{ west: number; east: number; south: number; north: number } | null>;
}

// Simple synchronous implementation for testing
class SimpleMapDataProcessor {
  private villas: NormalizedVilla[] = [];
  private alerts: Alert[] = [];
  private alertVillaIds: Set<string> = new Set();

  init({ villas, alerts }: { villas: NormalizedVilla[]; alerts: Alert[] }) {
    this.villas = villas;
    
    // Ensure alerts is an array and handle potential undefined/null values
    if (!Array.isArray(alerts)) {
      console.warn('Alerts is not an array:', alerts);
      this.alerts = [];
      this.alertVillaIds = new Set();
    } else {
      this.alerts = alerts;
      this.alertVillaIds = new Set(alerts.map(alert => alert.Account_ID));
    }
    

  }

  filterAndCluster(params: {
    viewportBounds: { west: number; east: number; south: number; north: number };
    cameraHeight: number;
    emirate: string;
    showNonAlertAboveZoom: boolean;
  }) {
    const { viewportBounds, cameraHeight, emirate } = params;
    
    // Filter villas by emirate
    let filteredVillas = this.villas;
    if (emirate !== 'All') {
      const emirateMapping: Record<string, string> = {
        'Dubai': 'Dubai',
        'Abu Dhabi': 'Abu Dhabi',
        'Sharjah': 'Sharjah',
        'Ajman': 'Ajman',
        'Umm Al Quwain': 'Umm Al Quwain',
        'Ras Al Khaimah': 'Ras Al Khaimah',
        'Fujairah': 'Fujairah',
      };
      
      filteredVillas = this.villas.filter(villa => 
        emirateMapping[villa.City] === emirate
      );
    }

    // Filter by viewport bounds
    const viewportVillas = filteredVillas.filter(villa => 
      villa.Longitude >= viewportBounds.west && 
      villa.Longitude <= viewportBounds.east && 
      villa.Latitude >= viewportBounds.south && 
      villa.Latitude <= viewportBounds.north
    );

    // Determine which villas to show based on camera height
    const shouldShowNonAlertVillas = cameraHeight < 100000; // 100km threshold
    const showAllVillas = shouldShowNonAlertVillas;

    // Create markers
    const markers = [];
    
    for (const villa of viewportVillas) {
      const hasAlert = this.alertVillaIds.has(villa.Account_Number);
      const alert = this.alerts.find(a => a.Account_ID === villa.Account_Number);
      

      
      // Show alert villas always, show non-alert villas based on threshold
      if (hasAlert || showAllVillas) {
        markers.push({
          id: villa.Account_Number,
          lon: villa.Longitude,
          lat: villa.Latitude,
          isAlert: hasAlert,
          status: alert?.Status === 'Open' ? 'open' : 'closed',
          accountNumber: villa.Account_Number,
          customerName: villa.Customer_Name,
          alertData: alert,
        });
      }
    }

    // Simple clustering - group nearby markers
    const clusters: Array<{ lon: number; lat: number; count: number }> = [];
    const processed = new Set<string>();
    const clusterDistance = cameraHeight > 50000 ? 0.02 : 0.01;

    for (let i = 0; i < markers.length; i++) {
      if (processed.has(markers[i].id)) continue;

      const cluster = [markers[i]];
      processed.add(markers[i].id);

      for (let j = i + 1; j < markers.length; j++) {
        if (processed.has(markers[j].id)) continue;

        const distance = Math.sqrt(
          Math.pow(markers[i].lon - markers[j].lon, 2) + 
          Math.pow(markers[i].lat - markers[j].lat, 2)
        );

        if (distance <= clusterDistance) {
          cluster.push(markers[j]);
          processed.add(markers[j].id);
        }
      }

      if (cluster.length > 1) {
        const avgLon = cluster.reduce((sum, m) => sum + m.lon, 0) / cluster.length;
        const avgLat = cluster.reduce((sum, m) => sum + m.lat, 0) / cluster.length;
        clusters.push({ lon: avgLon, lat: avgLat, count: cluster.length });
      }
    }

    // Remove markers that are part of clusters
    const individualMarkers = markers.filter(marker => {
      return !clusters.some(cluster => {
        const distance = Math.sqrt(
          Math.pow(marker.lon - cluster.lon, 2) + 
          Math.pow(marker.lat - cluster.lat, 2)
        );
        return distance <= clusterDistance;
      });
    });



    return Promise.resolve({
      clusters,
      markers: individualMarkers
    });
  }

  getEmirateBounds(emirate: string) {
    const bounds = {
      "Dubai": { west: 55.0, east: 55.6, south: 24.9, north: 25.5 },
      "Abu Dhabi": { west: 52.5, east: 55.5, south: 22.5, north: 25.3 },
      "Sharjah": { west: 55.3, east: 55.9, south: 25.1, north: 25.5 },
      "Ajman": { west: 55.4, east: 55.6, south: 25.3, north: 25.5 },
      "Umm Al Quwain": { west: 55.5, east: 55.8, south: 25.5, north: 25.7 },
      "Ras Al Khaimah": { west: 55.6, east: 56.2, south: 25.5, north: 26.2 },
      "Fujairah": { west: 56.0, east: 56.5, south: 25.0, north: 25.7 },
      "All": { west: 52.5, east: 56.6, south: 22.5, north: 26.5 }
    };
    
    return Promise.resolve(bounds[emirate as keyof typeof bounds] || null);
  }
}

export function useMapDataWorker() {
  const processorRef = useRef<SimpleMapDataProcessor | null>(null);
  const [isWorkerReady, setIsWorkerReady] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [workerError, setWorkerError] = useState<string | null>(null);

  const { data: villasData } = useVillas();
  const { data: alertsData } = useAlerts();
  const { emirate } = useUIStore();
  const { viewportBounds, cameraHeight, setViewportBounds, setCameraHeight } = useMapStore();

  // Initialize processor
  useEffect(() => {
    try {
      if (!processorRef.current) {
        processorRef.current = new SimpleMapDataProcessor();
      }
    } catch (error) {
      console.error('Error creating processor:', error);
      setWorkerError('Failed to create processor');
    }

    return () => {
      if (processorRef.current) {
        processorRef.current = null;
        setIsWorkerReady(false);
        setWorkerError(null);
      }
    };
  }, []);

  // Initialize processor with data
  useEffect(() => {
    if (processorRef.current && villasData?.data && !isWorkerReady) {
      try {
        // Ensure alertsData is an array
        const alertsArray = Array.isArray(alertsData) ? alertsData : [];
        
        processorRef.current.init({
          villas: villasData.data,
          alerts: alertsArray,
        });
        setIsWorkerReady(true);
        setWorkerError(null);
      } catch (error) {
        console.error('Failed to initialize SimpleMapDataProcessor:', error);
        setWorkerError('Failed to initialize processor with data');
      }
    }
  }, [villasData?.data, alertsData, isWorkerReady]);

  // Process map data
  const processMapData = useCallback(async () => {
    if (!processorRef.current || !isWorkerReady || !viewportBounds || isProcessing) {
      return { clusters: [], markers: [] };
    }

    setIsProcessing(true);
    try {
      const result = await processorRef.current.filterAndCluster({
        viewportBounds,
        cameraHeight,
        emirate,
        showNonAlertAboveZoom: false,
      });
      return result;
    } catch (error) {
      console.error('Error processing map data:', error);
      return { clusters: [], markers: [] };
    } finally {
      setIsProcessing(false);
    }
  }, [processorRef, isWorkerReady, viewportBounds, cameraHeight, emirate, isProcessing]);

  // Get emirate bounds
  const getEmirateBounds = useCallback(async (emirateName: string) => {
    if (!processorRef.current || !isWorkerReady) {
      return null;
    }

    try {
      return await processorRef.current.getEmirateBounds(emirateName);
    } catch (error) {
      console.error('Error getting emirate bounds:', error);
      return null;
    }
  }, [processorRef, isWorkerReady]);

  return {
    isWorkerReady,
    isProcessing,
    workerError,
    processMapData,
    getEmirateBounds,
    setViewportBounds,
    setCameraHeight,
  };
} 