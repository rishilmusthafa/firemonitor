import { expose } from 'comlink';

interface Alert {
  id: string;
  Account_ID: string;
  User_ID?: string;
  Mobile?: string;
  Title: string;
  Type: string;
  Alert_DateTime: string;
  Status: 'Open' | 'Closed';
  Premise_ID?: string;
  Title_Ar?: string;
  Type_Ar?: string;
}

interface ProcessedAlert {
  id: string;
  accountId: string;
  title: string;
  titleAr?: string;
  datetime: string;
  status: 'closed' | 'countdown' | 'overdue';
  secondsRemaining?: number;
  mobile?: string;
  type: string;
}

interface ProcessTodayResult {
  openToday: number;
  totalToday: number;
  items: ProcessedAlert[];
}

interface Villa {
  Account_Number: string;
  Customer_Name: string;
  Email_Address?: string;
  Latitude: number;
  Longitude: number;
  Address?: string;
  City: string;
}

class AlertsWorker {
  private alerts: Alert[] = [];
  private villas: Villa[] = [];
  private nowUtc: string = '';

  init({ alerts, villas, nowUtc }: { alerts: Alert[]; villas: Villa[]; nowUtc: string }) {
    this.alerts = alerts;
    this.villas = villas;
    this.nowUtc = nowUtc;

  }

  processToday({ nowUtc }: { nowUtc: string }): ProcessTodayResult {
    this.nowUtc = nowUtc;
    const now = new Date(nowUtc);
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);

    // Filter alerts for today
    const todayAlerts = this.alerts.filter(alert => {
      const alertDate = new Date(alert.Alert_DateTime);
      return alertDate >= todayStart && alertDate < todayEnd;
    });

    // Process each alert
    const processedAlerts: ProcessedAlert[] = todayAlerts.map(alert => {
      const alertDate = new Date(alert.Alert_DateTime);
      const secondsSinceAlert = Math.floor((now.getTime() - alertDate.getTime()) / 1000);
      
      let status: 'closed' | 'countdown' | 'overdue';
      let secondsRemaining: number | undefined;

      if (alert.Status === 'Closed') {
        status = 'closed';
      } else {
        // Open alerts: check if within 30-minute window
        const thirtyMinutes = 30 * 60; // 30 minutes in seconds
        if (secondsSinceAlert <= thirtyMinutes) {
          status = 'countdown';
          secondsRemaining = thirtyMinutes - secondsSinceAlert;
        } else {
          status = 'overdue';
        }
      }

      // Find matching villa for additional info
      const villa = this.villas.find(v => v.Account_Number === alert.Account_ID);

      return {
        id: alert.id,
        accountId: alert.Account_ID,
        title: alert.Title,
        titleAr: alert.Title_Ar,
        datetime: alert.Alert_DateTime,
        status,
        secondsRemaining,
        mobile: alert.Mobile,
        type: alert.Type,
      };
    });

    const openToday = processedAlerts.filter(alert => alert.status !== 'closed').length;
    const totalToday = processedAlerts.length;

    return {
      openToday,
      totalToday,
      items: processedAlerts
    };
  }

  getAlertStats(): {
    totalAlerts: number;
    openAlerts: number;
    closedAlerts: number;
    overdueAlerts: number;
    countdownAlerts: number;
  } {
    const now = new Date(this.nowUtc);
    const thirtyMinutes = 30 * 60; // 30 minutes in seconds

    let openAlerts = 0;
    let closedAlerts = 0;
    let overdueAlerts = 0;
    let countdownAlerts = 0;

    this.alerts.forEach(alert => {
      if (alert.Status === 'Closed') {
        closedAlerts++;
      } else {
        const alertDate = new Date(alert.Alert_DateTime);
        const secondsSinceAlert = Math.floor((now.getTime() - alertDate.getTime()) / 1000);
        
        if (secondsSinceAlert <= thirtyMinutes) {
          countdownAlerts++;
        } else {
          overdueAlerts++;
        }
        openAlerts++;
      }
    });

    return {
      totalAlerts: this.alerts.length,
      openAlerts,
      closedAlerts,
      overdueAlerts,
      countdownAlerts,
    };
  }

  getAlertsByEmirate(emirate: string): Alert[] {
    if (emirate === 'All') {
      // For 'All', deduplicate by account ID and keep latest
      const alertMap = new Map<string, Alert>();
      this.alerts.forEach(alert => {
        const existing = alertMap.get(alert.Account_ID);
        if (!existing || new Date(alert.Alert_DateTime) > new Date(existing.Alert_DateTime)) {
          alertMap.set(alert.Account_ID, alert);
        }
      });
      return Array.from(alertMap.values());
    }

    // Get villa account numbers for the selected emirate (case-insensitive comparison)
    const emirateVillaIds = new Set(
      this.villas
        .filter(villa => villa.City?.toLowerCase() === emirate.toLowerCase())
        .map(villa => villa.Account_Number)
    );

    // Filter alerts for villas in the selected emirate and deduplicate by account ID
    const emirateAlerts = this.alerts.filter(alert => emirateVillaIds.has(alert.Account_ID));
    const alertMap = new Map<string, Alert>();
    
    emirateAlerts.forEach(alert => {
      const existing = alertMap.get(alert.Account_ID);
      if (!existing || new Date(alert.Alert_DateTime) > new Date(existing.Alert_DateTime)) {
        alertMap.set(alert.Account_ID, alert);
      }
    });

    return Array.from(alertMap.values());
  }
}

expose(AlertsWorker); 