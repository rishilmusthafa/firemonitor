import { NextRequest, NextResponse } from 'next/server';
import { readFileSync } from 'fs';
import { join } from 'path';
import { AlertsArraySchema } from '@/lib/schemas';
import { analyzeData, filterLatestAlertsPerVilla } from '@/utils/dataUtils';
import type { Alert } from '@/types/alerts';
import type { Villa } from '@/types/villas';

export const runtime = 'nodejs';

export async function GET() {
  try {
    // Read alerts data from file
    const alertsPath = join(process.cwd(), 'src', 'data', 'alerts.json');
    const alertsRawData = readFileSync(alertsPath, 'utf-8');
    const alertsData = JSON.parse(alertsRawData) as Alert[];
    
    // Read villas data for analysis
    const villasPath = join(process.cwd(), 'src', 'data', 'villas.json');
    const villasRawData = readFileSync(villasPath, 'utf-8');
    const villasData = JSON.parse(villasRawData) as Villa[];
    
    // Validate alerts data
    const validatedAlerts = AlertsArraySchema.parse(alertsData);
    
    // Filter to keep only the latest alert per villa
    const filteredAlerts = filterLatestAlertsPerVilla(validatedAlerts);
    
    // Perform data analysis on filtered alerts
    const analysis = analyzeData(villasData, filteredAlerts);
    
    // Log data analysis
    console.log('=== ALERTS DATA ANALYSIS ===');
    console.log(`Original alerts: ${validatedAlerts.length}`);
    console.log(`Filtered alerts (latest per villa): ${filteredAlerts.length}`);
    console.log(`Duplicates removed: ${validatedAlerts.length - filteredAlerts.length}`);
    console.log(`Today's alerts: ${analysis.todayAlerts}`);
    console.log(`Orphan alerts (no matching villa): ${analysis.orphanAlerts}`);
    console.log(`Total villas: ${analysis.totalVillas}`);
    console.log(`Unique account numbers: ${analysis.uniqueAccountNumbers}`);
    console.log(`Cities found: ${analysis.cities.length}`);
    console.log(`Emirates found: ${analysis.emirates.length}`);
    
    // Get today's alerts from filtered data
    const todayAlerts = filteredAlerts.filter(alert => {
      const alertDate = new Date(alert.Alert_DateTime);
      const today = new Date();
      return alertDate.toDateString() === today.toDateString();
    });
    
    return NextResponse.json({
      success: true,
      data: filteredAlerts,
      count: filteredAlerts.length,
      originalCount: validatedAlerts.length,
      duplicatesRemoved: validatedAlerts.length - filteredAlerts.length,
      todayAlerts: todayAlerts,
      todayCount: todayAlerts.length,
      analysis
    });
    
  } catch (error) {
    console.error('Error loading alerts data:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to load alerts data',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
} 