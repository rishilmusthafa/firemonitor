import LoaderDemo from '@/components/LoaderDemo';

export default function DemoPage() {
  return <LoaderDemo />;
} 