'use client';

import { useEffect, useState } from 'react';

interface CountdownTimerProps {
  secondsRemaining: number;
  onComplete?: () => void;
  className?: string;
}

export default function CountdownTimer({ secondsRemaining, onComplete, className = '' }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState(secondsRemaining);

  useEffect(() => {
    setTimeLeft(secondsRemaining);
  }, [secondsRemaining]);

  useEffect(() => {
    if (timeLeft <= 0) {
      onComplete?.();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onComplete?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onComplete]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getColorClass = () => {
    if (timeLeft <= 300) return 'text-red-500'; // Last 5 minutes
    if (timeLeft <= 600) return 'text-orange-500'; // Last 10 minutes
    return 'text-green-500';
  };

  return (
    <span className={`font-mono font-bold ${getColorClass()} ${className}`}>
      {formatTime(timeLeft)}
    </span>
  );
} 