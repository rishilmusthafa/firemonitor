'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAlerts } from '@/hooks/useAlerts';

export default function RefreshButton() {
  const { refetch, isFetching } = useAlerts();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    if (isRefreshing || isFetching) return;
    
    setIsRefreshing(true);
    try {
      await refetch();
    } catch (error) {
      console.error('❌ Manual refresh failed:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <motion.button
      onClick={handleRefresh}
      disabled={isRefreshing || isFetching}
      className={`
        fixed top-16 right-4 z-50 w-10 h-10 rounded-full
        bg-background/80 backdrop-blur-sm border border-secondary/20
        hover:bg-background/90 hover:border-secondary/40
        disabled:opacity-50 disabled:cursor-not-allowed
        transition-all duration-200
        flex items-center justify-center
        ${isRefreshing || isFetching ? 'animate-pulse' : ''}
      `}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      title="Refresh alerts data"
    >
      <motion.svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-textPrimary"
        animate={isRefreshing || isFetching ? { rotate: 360 } : {}}
        transition={{ 
          duration: 1, 
          repeat: isRefreshing || isFetching ? Infinity : 0,
          ease: "linear"
        }}
      >
        <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
        <path d="M21 3v5h-5" />
        <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
        <path d="M3 21v-5h5" />
      </motion.svg>
    </motion.button>
  );
} 