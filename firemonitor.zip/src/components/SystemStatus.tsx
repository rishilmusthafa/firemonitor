'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';

export default function SystemStatus() {
  const [mounted, setMounted] = useState(false);
  const [status, setStatus] = useState<'online' | 'offline' | 'warning'>('online');
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    setMounted(true);
    setLastUpdate(new Date());
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const interval = setInterval(() => {
      const random = Math.random();
      if (random > 0.8) {
        setStatus('warning');
      } else if (random > 0.95) {
        setStatus('offline');
      } else {
        setStatus('online');
      }
      setLastUpdate(new Date());
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [mounted]);

  if (!mounted) {
    return <div className="w-48 h-16" />;
  }

  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'warning':
        return 'bg-yellow-500';
      case 'offline':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'online':
        return 'System Online';
      case 'warning':
        return 'System Warning';
      case 'offline':
        return 'System Offline';
      default:
        return 'Unknown';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ 
        scale: 1.02,
        transition: { duration: 0.2 }
      }}
    >
      <Card className="bg-background/80 backdrop-blur-sm border border-secondary/20">
        <CardContent className="p-3">
          <div className="flex items-center space-x-3">
            <motion.div
              className={`w-3 h-3 rounded-full ${getStatusColor()}`}
              animate={{
                scale: status === 'online' ? [1, 1.2, 1] : 1,
                opacity: status === 'offline' ? [1, 0.5, 1] : 1,
              }}
              transition={{
                duration: 2,
                repeat: status === 'online' || status === 'offline' ? Infinity : 0,
              }}
            />
            <div className="flex-1">
              <motion.div 
                className="text-sm font-medium text-textPrimary"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.3 }}
              >
                {getStatusText()}
              </motion.div>
              {lastUpdate && (
                <motion.div 
                  className="text-xs text-textSecondary"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.3 }}
                >
                  Last update: {lastUpdate.toLocaleTimeString()}
                </motion.div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
} 