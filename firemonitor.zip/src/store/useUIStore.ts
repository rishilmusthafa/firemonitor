import { create } from 'zustand';

export type Emirate = 'All' | 'Dubai' | 'Abu Dhabi' | 'Sharjah' | 'Ajman' | 'Umm Al Quwain' | 'Ras Al Khaimah' | 'Fujairah';

interface UIState {
  emirate: Emirate;
  setEmirate: (emirate: Emirate) => void;
}

export const useUIStore = create<UIState>((set) => ({
  emirate: 'All',
  setEmirate: (emirate: Emirate) => set({ emirate }),
})); 